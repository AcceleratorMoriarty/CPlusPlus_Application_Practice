#include "lightwidget.h"
#include <QDebug>
#include <QPainter>
#include <QTimer>
#include "ui_lightwidget.h"

LightWidget::LightWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LightWidget)
{
    ui->setupUi(this);

    timer = new QTimer(this);
    timer->start(1000);
    ui->lightwgt_r->SetLightColor(LightWgt::bGray);
    ui->lightwgt_y->SetLightColor(LightWgt::bGray);
    ui->lightwgt_g->SetLightColor(LightWgt::bGray);

    ui->lightbtn_1->SetLightColor(LightButton::bGray);
    ui->lightbtn_2->SetLightColor(LightButton::bGray);
    ui->lightbtn_3->SetLightColor(LightButton::bGray);

    currentTime = 0;
    connect(timer, &QTimer::timeout, this, &LightWidget::changeLightColor);
}

LightWidget::~LightWidget()
{
    delete ui;
}

void LightWidget::changeLightColor(void)
{
    if (btnflag == 1) {
        currentTime %= 27;
        currentTime++;
        qDebug() << " currentTime " << currentTime;
        if (currentTime <= 15) {
            ui->lightwgt_r->SetLightColor(LightWgt::bRed);
            ui->lightwgt_y->SetLightColor(LightWgt::bGray);
            ui->lightwgt_g->SetLightColor(LightWgt::bGray);
            ui->pushButton->setText(
                QString("当前状态:红灯(%1s)\n红:15s 黄:2s 绿:10s")
                    .arg(QString::number(currentTime, 10).QString::rightJustified(2, '0')));
        } else if (currentTime > 15 && currentTime <= 17) {
            ui->lightwgt_r->SetLightColor(LightWgt::bGray);
            ui->lightwgt_y->SetLightColor(LightWgt::bYellow);
            ui->lightwgt_g->SetLightColor(LightWgt::bGray);
            ui->pushButton->setText(
                QString("当前状态:黄灯(%1s)\n红:15s 黄:2s 绿:10s")
                    .arg(QString::number(currentTime - 15, 10).QString::rightJustified(2, '0')));
        } else if (currentTime > 17) {
            ui->lightwgt_r->SetLightColor(LightWgt::bGray);
            ui->lightwgt_y->SetLightColor(LightWgt::bGray);
            ui->lightwgt_g->SetLightColor(LightWgt::bGreen);
            ui->pushButton->setText(
                QString("当前状态:绿灯(%1s)\n红:15s 黄:2s 绿:10s")
                    .arg(QString::number(currentTime - 17, 10).QString::rightJustified(2, '0')));
        }
    }
    if (button23Time)
        ui->lightbtn_3->SetLightColor(LightButton::bGray);
    else
        ui->lightbtn_3->SetLightColor(LightButton::bGreen);

    if (redflag == 0) {
        ui->lightbtn_1->SetLightColor(LightButton::bGray);
        ui->lightbtn_1->setEnabled(false);
    } else if (redflag == 1) {
        ui->lightbtn_1->setEnabled(true);
        ui->lightbtn_1->SetLightColor(LightButton::bGray);
        switch (button1Time) {
        case 0:
            ui->lightbtn_1->SetLightColor(LightButton::bRed);
            break;
        case 1:
            ui->lightbtn_1->SetLightColor(LightButton::bYellow);
            break;
        case 2:
            ui->lightbtn_1->SetLightColor(LightButton::bGreen);
            break;
        default:
            break;
        }

        button1Time++;
        button1Time %= 3;
    }
    if (yellowflag == 0) {
        ui->lightbtn_2->SetLightColor(LightButton::bGray);
        ui->lightbtn_2->setEnabled(false);
    } else if (yellowflag == 1) {
        ui->lightbtn_2->setEnabled(true);
        ui->lightbtn_2->SetLightColor(LightButton::bGray);
        if (button23Time)
            ui->lightbtn_2->SetLightColor(LightButton::bYellow);
        else
            ui->lightbtn_2->SetLightColor(LightButton::bGray);
    }
    button23Time++;
    button23Time %= 2;
}

void LightWidget::on_pushButton_clicked()
{
    btnflag++;
    btnflag %= 2;
    if (!btnflag) {
        currentTime = 0;
        ui->pushButton->setText("当前状态:关闭\n红:15s 黄:2s 绿:10s");
    }
}

void LightWidget::on_btn_layout_clicked()
{
    // 获取原始布局
    QLayout *currentLayout = ui->widget->layout();

    // 删除原始布局并释放内存
    if (currentLayout) {
        QLayoutItem *item;
        while ((item = currentLayout->takeAt(0)) != nullptr) {
            delete item;
        }
        delete currentLayout;
    }

    if (!layoutflag) {
        QVBoxLayout *layoutV = new QVBoxLayout();
        layoutV->addWidget(ui->lightwgt_r);
        layoutV->addWidget(ui->lightwgt_y);
        layoutV->addWidget(ui->lightwgt_g);

        ui->widget->setLayout(layoutV);
        ui->widget->layout()->activate();
        ui->btn_layout->setText("QVBoxLayout");
    } else {
        QHBoxLayout *layoutH = new QHBoxLayout();
        layoutH->addWidget(ui->lightwgt_r);
        layoutH->addWidget(ui->lightwgt_y);
        layoutH->addWidget(ui->lightwgt_g);

        ui->widget->setLayout(layoutH);
        ui->widget->layout()->activate();
        ui->btn_layout->setText("QHBoxLayout");
    }

    layoutflag++;
    layoutflag %= 2;
}

void LightWidget::on_lightbtn_2_clicked()
{
    redflag++;
    redflag %= 2;
}

void LightWidget::on_lightbtn_3_clicked()
{
    yellowflag++;
    yellowflag %= 2;
}
