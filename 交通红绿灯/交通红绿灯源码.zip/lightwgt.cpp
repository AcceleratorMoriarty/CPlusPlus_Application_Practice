#include "lightwgt.h"
#include <QDebug>
#include <QPainter>
#include <QPainterPath>

LightWgt::LightWgt(QWidget *parent)
    : QWidget(parent)
{
    borderOutColorStart = QColor(255, 255, 255);
    borderOutColorEnd = QColor(166, 166, 166);

    borderInColorStart = QColor(166, 166, 166);
    borderInColorEnd = QColor(255, 255, 255);

    overlayColor = QColor(255, 255, 255);
}

void LightWgt::paintEvent(QPaintEvent *)
{
    int width = this->width();
    int height = this->height();
    int side = qMin(width, height);

    QPainter painter(this);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);
    painter.translate(width / 2, height / 2);
    painter.scale(side / 200.0, side / 200.0);

    //外边框
    drawBorderOut(&painter);
    //内边框
    drawBorderIn(&painter);
    //内部颜色
    drawBg(&painter);
    //遮罩层
    drawOverlay(&painter);
}

void LightWgt::drawBorderOut(QPainter *painter)
{
    int radius = 100;
    painter->save();
    painter->setPen(Qt::NoPen);
    QLinearGradient borderGradient(0, -radius, 0, radius);
    borderGradient.setColorAt(0, borderOutColorStart);
    borderGradient.setColorAt(1, borderOutColorEnd);
    painter->setBrush(borderGradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightWgt::drawBorderIn(QPainter *painter)
{
    int radius = 88;
    painter->save();
    painter->setPen(Qt::NoPen);
    QLinearGradient borderGradient(0, -radius, 0, radius);
    borderGradient.setColorAt(0, borderInColorStart);
    borderGradient.setColorAt(1, borderInColorEnd);
    painter->setBrush(borderGradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightWgt::drawBg(QPainter *painter)
{
    int radius = 85;
    painter->save();
    painter->setPen(Qt::NoPen);
    QRadialGradient gradient(0, 0, radius);
    setrgColor(&gradient);
    painter->setBrush(gradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightWgt::drawOverlay(QPainter *painter)
{
    int radius = 100;
    painter->save();
    painter->setPen(Qt::NoPen);

    QPainterPath smallCircle;
    QPainterPath bigCircle;
    radius -= 1;
    smallCircle.addEllipse(-radius, -radius, radius * 2, radius * 2);
    radius *= 2;
    bigCircle.addEllipse(-radius, -radius + 170, radius * 2, radius * 2);
    QPainterPath highlight = smallCircle - bigCircle;
    QLinearGradient linearGradient(0, -radius / 2, 0, 0);
    overlayColor.setAlpha(100);
    linearGradient.setColorAt(0.0, overlayColor);
    overlayColor.setAlpha(30);
    linearGradient.setColorAt(1.0, overlayColor);
    painter->setBrush(linearGradient);
    painter->rotate(-20);
    painter->drawPath(highlight);

    painter->restore();
}

void LightWgt::SetLightColor(enum LightColors color)
{
    c = color;
}

void LightWgt::setrgColor(QRadialGradient *rg)
{
    this->update();

    switch (c) {
    case bRed:
        rg->setColorAt(0.0, QColor(245, 0, 0));
        rg->setColorAt(0.6, QColor(210, 0, 0));
        rg->setColorAt(1.0, QColor(140, 0, 0));
        break;
    case bGreen:
        rg->setColorAt(0.0, QColor(0, 245, 0));
        rg->setColorAt(0.6, QColor(0, 210, 0));
        rg->setColorAt(1.0, QColor(0, 140, 0));
        break;
    case bYellow:
        rg->setColorAt(0.0, QColor(245, 245, 0));
        rg->setColorAt(0.6, QColor(210, 210, 0));
        rg->setColorAt(1.0, QColor(140, 140, 0));
        break;
    case bGray:
        rg->setColorAt(0.0, QColor(245, 245, 245));
        rg->setColorAt(0.6, QColor(210, 210, 210));
        rg->setColorAt(1.0, QColor(140, 140, 140));
        break;
    default:
        rg->setColorAt(0.0, QColor(245, 245, 245));
        rg->setColorAt(0.6, QColor(210, 210, 210));
        rg->setColorAt(1.0, QColor(140, 140, 140));
        break;
    }
}
