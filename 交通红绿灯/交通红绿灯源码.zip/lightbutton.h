﻿#ifndef LIGHTBUTTON_H
#define LIGHTBUTTON_H

#include <QPainter>
#include <QPushButton>
#include <QWidget>

namespace Ui {
class LightButton;
}

class LightButton : public QPushButton
{
    Q_OBJECT

public:
    LightButton(QWidget *parent = nullptr)
        : QPushButton(parent)
    {
        borderOutColorStart = QColor(255, 255, 255);
        borderOutColorEnd = QColor(166, 166, 166);

        borderInColorStart = QColor(166, 166, 166);
        borderInColorEnd = QColor(255, 255, 255);

        overlayColor = QColor(255, 255, 255);
    }

protected:
    void paintEvent(QPaintEvent *event) override;
    void drawBorderOut(QPainter *painter);
    void drawBorderIn(QPainter *painter);
    void drawBg(QPainter *painter);
    void drawOverlay(QPainter *painter);

private:
    QColor borderOutColorStart; //外边框渐变开始颜色
    QColor borderOutColorEnd;   //外边框渐变结束颜色
    QColor borderInColorStart;  //里边框渐变开始颜色
    QColor borderInColorEnd;    //里边框渐变结束颜色
    QColor overlayColor;        //遮罩层颜色

    uint8_t c;

public:
    //定义颜色枚举变量
    enum LightColors { bRed, bGreen, bYellow, bGray };

    void setrgColor(QRadialGradient *rg);
    void SetLightColor(enum LightColors color);
};

#endif // LIGHTBUTTON_H
