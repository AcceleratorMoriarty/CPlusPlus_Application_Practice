﻿#include "lightbutton.h"
#include "qdebug.h"
#include "qevent.h"
#include "qpainter.h"
#include "qpainterpath.h"
#include "qtimer.h"

void LightButton::paintEvent(QPaintEvent *event)
{
    QPushButton::paintEvent(event); // 调用基类的 paintEvent 以确保按钮正常绘制

    int width = this->width();
    int height = this->height();
    int side = qMin(width, height);

    QPainter painter(this);
    painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);
    painter.translate(width / 2, height / 2);
    painter.scale(side / 200.0, side / 200.0);

    //外边框
    drawBorderOut(&painter);
    //内边框
    drawBorderIn(&painter);
    //内部颜色
    drawBg(&painter);
    //遮罩层
    drawOverlay(&painter);
}

void LightButton::drawBorderOut(QPainter *painter)
{
    int radius = 90;
    painter->save();
    painter->setPen(Qt::NoPen);
    QLinearGradient borderGradient(0, -radius, 0, radius);
    borderGradient.setColorAt(0, borderOutColorStart);
    borderGradient.setColorAt(1, borderOutColorEnd);
    painter->setBrush(borderGradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightButton::drawBorderIn(QPainter *painter)
{
    int radius = 80;
    painter->save();
    painter->setPen(Qt::NoPen);
    QLinearGradient borderGradient(0, -radius, 0, radius);
    borderGradient.setColorAt(0, borderInColorStart);
    borderGradient.setColorAt(1, borderInColorEnd);
    painter->setBrush(borderGradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightButton::drawBg(QPainter *painter)
{
    int radius = 75;
    painter->save();
    painter->setPen(Qt::NoPen);
    QRadialGradient gradient(0, 0, radius);
    setrgColor(&gradient);
    painter->setBrush(gradient);
    painter->drawEllipse(-radius, -radius, radius * 2, radius * 2);
    painter->restore();
}

void LightButton::drawOverlay(QPainter *painter)
{
    int radius = 90;
    painter->save();
    painter->setPen(Qt::NoPen);

    QPainterPath smallCircle;
    QPainterPath bigCircle;
    radius -= 1;
    smallCircle.addEllipse(-radius, -radius, radius * 2, radius * 2);
    radius *= 2;
    bigCircle.addEllipse(-radius, -radius + 170, radius * 2, radius * 2);
    QPainterPath highlight = smallCircle - bigCircle;
    QLinearGradient linearGradient(0, -radius / 2, 0, 0);
    overlayColor.setAlpha(100);
    linearGradient.setColorAt(0.0, overlayColor);
    overlayColor.setAlpha(30);
    linearGradient.setColorAt(1.0, overlayColor);
    painter->setBrush(linearGradient);
    painter->rotate(-20);
    painter->drawPath(highlight);

    painter->restore();
}

void LightButton::SetLightColor(enum LightColors color)
{
    c = color;
}

void LightButton::setrgColor(QRadialGradient *rg)
{
    this->update();

    switch (c) {
    case bRed:
        rg->setColorAt(0.0, QColor(245, 0, 0));
        rg->setColorAt(0.6, QColor(210, 0, 0));
        rg->setColorAt(1.0, QColor(140, 0, 0));
        break;
    case bGreen:
        rg->setColorAt(0.0, QColor(0, 245, 0));
        rg->setColorAt(0.6, QColor(0, 210, 0));
        rg->setColorAt(1.0, QColor(0, 140, 0));
        break;
    case bYellow:
        rg->setColorAt(0.0, QColor(245, 245, 0));
        rg->setColorAt(0.6, QColor(210, 210, 0));
        rg->setColorAt(1.0, QColor(140, 140, 0));
        break;
    case bGray:
        rg->setColorAt(0.0, QColor(245, 245, 245));
        rg->setColorAt(0.6, QColor(210, 210, 210));
        rg->setColorAt(1.0, QColor(140, 140, 140));
        break;
    default:
        rg->setColorAt(0.0, QColor(245, 245, 245));
        rg->setColorAt(0.6, QColor(210, 210, 210));
        rg->setColorAt(1.0, QColor(140, 140, 140));
        break;
    }
}
