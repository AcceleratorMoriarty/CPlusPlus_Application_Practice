#ifndef LIGHTWIDGET_H
#define LIGHTWIDGET_H#include <QTimer>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class LightWidget; }
QT_END_NAMESPACE

class LightWidget : public QWidget
{
    Q_OBJECT

public:
    LightWidget(QWidget *parent = nullptr);
    ~LightWidget();

private slots:
    void on_pushButton_clicked();

    void on_btn_layout_clicked();

    void on_lightbtn_2_clicked();

    void on_lightbtn_3_clicked();

private:
    Ui::LightWidget *ui;

    QTimer *timer;
    uint8_t currentTime;
    uint8_t button1Time;
    uint8_t button23Time;

    uint8_t btnflag = 1;
    uint8_t layoutflag = 0;
    uint8_t redflag = 1;
    uint8_t yellowflag = 1;

    void changeLightColor(void);
};
#endif // LIGHTWIDGET_H
