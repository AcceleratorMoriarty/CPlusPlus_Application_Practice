#ifndef PLOTWIDGET_H
#define PLOTWIDGET_H

#include <QTimer>
#include <QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE
namespace Ui { class PlotWidget; }
QT_END_NAMESPACE

class PlotWidget : public QWidget
{
    Q_OBJECT

public:
    PlotWidget(QWidget *parent = nullptr);
    ~PlotWidget();

    //public slots:
    //    void realtimeDataSlot();

protected:
    void plotSetupMultiple();
    void InitData(QVector<double> &obj);
    void Time_Update(void);
    //    void plotRealTimeSetup();

private slots:
    void on_pushButton_go_clicked();

    void on_spinBox_step_valueChanged(int arg1);

    void on_comboBox_round_currentIndexChanged(int index);

    void on_pushButton_reset_clicked();

    void on_pushButton_color1_clicked();

    void on_checkBox_same_stateChanged(int arg1);

    void on_pushButton_color2_clicked();

private:
    Ui::PlotWidget *ui;
    QCPBars *Bar_Money;
    QCPBars *Bar_Sort;

    QVector<double> MoneyData;
    QVector<double> SortData;

    int round = 0;
    int step = 0;
    int totalSteps = 10;
    int totalRounds = 1500; // 模拟总轮次
    QTimer *timer;

    int go_flag = 0;

    QColor color_Money = QColor("lightblue");
    QColor color_Sort = QColor("lightcoral");
};
#endif // PLOTWIDGET_H
