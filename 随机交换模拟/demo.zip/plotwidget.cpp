#include "plotwidget.h"
#include <QColorDialog>
#include <QDebug>
#include <QRandomGenerator>
#include <QTime>
#include <QTimer>
#include "ui_plotwidget.h"
#include <stdlib.h>

PlotWidget::PlotWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PlotWidget)
{
    ui->setupUi(this);
    InitData(MoneyData);
    InitData(SortData);
    plotSetupMultiple();
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &PlotWidget::Time_Update);
}

PlotWidget::~PlotWidget()
{
    delete ui;
}

void PlotWidget::Time_Update(void)
{
    if (round >= totalRounds) {
        timer->stop();
        return;
    }

    int Receiver;
    for (step = 0; step < totalSteps; step++) {
        for (int giver = 0; giver < 100; giver++) {
            Receiver = QRandomGenerator::global()->bounded(100);
            if (giver != Receiver && MoneyData[giver] > 0) {
                MoneyData[giver]--;
                MoneyData[Receiver]++;
            }
        }
        qDebug() << "step" << step;
    }

    SortData = MoneyData;
    std::sort(SortData.begin(), SortData.end());
    QVector<double> x(100);
    for (int i = 0; i < 100; i++) {
        x[i] = i;
    }

    Bar_Money->setData(x, MoneyData);
    Bar_Sort->setData(x, SortData);

    round = round + step;
    Bar_Money->setName(QString("Money: Round(%1)").arg(round));
    Bar_Sort->setName(QString("Money Sorted: Round(%1)").arg(round));
    qDebug() << "round" << round;

    ui->widget->replot(); // 重新绘制图表
}

void PlotWidget::plotSetupMultiple()
{
    auto customPlot = ui->widget;
    customPlot->plotLayout()->clear();
    //    customPlot->legend->setVisible(true);

    QCPAxisRect *MoneyAxisRect = new QCPAxisRect(customPlot);
    customPlot->plotLayout()->addElement(0, 0, MoneyAxisRect);
    MoneyAxisRect->axis(QCPAxis::atBottom)->setRange(0, 100);
    MoneyAxisRect->axis(QCPAxis::atLeft)->setRange(0, 350);

    QCPAxisRect *SortAxisRect = new QCPAxisRect(customPlot);
    customPlot->plotLayout()->addElement(1, 0, SortAxisRect);
    SortAxisRect->axis(QCPAxis::atBottom)->setRange(0, 100);
    SortAxisRect->axis(QCPAxis::atLeft)->setRange(0, 350);
    QList<QCPAxis *> allAxes;
    allAxes << MoneyAxisRect->axes() << SortAxisRect->axes();
    foreach (QCPAxis *axis, allAxes) {
        axis->setLayer("axes");
        axis->grid()->setLayer("grid");
    }

    QCPTextElement *title = new QCPTextElement(customPlot);
    title->setText("随机交换模拟");
    title->setFont(QFont("宋体", 12, QFont::Bold));
    customPlot->plotLayout()->insertRow(0);
    customPlot->plotLayout()->addElement(0, 0, title);

    QVector<double> x(100);
    for (int i = 0; i < 100; i++) {
        x[i] = i;
    }

    Bar_Money = new QCPBars(MoneyAxisRect->axis(QCPAxis::atBottom),
                            MoneyAxisRect->axis(QCPAxis::atLeft));
    Bar_Money->setPen(QPen(QColor("lightblue")));
    Bar_Money->setBrush(QColor("lightblue"));
    Bar_Money->setData(x, MoneyData);

    Bar_Sort = new QCPBars(SortAxisRect->axis(QCPAxis::atBottom),
                           SortAxisRect->axis(QCPAxis::atLeft));
    Bar_Sort->setPen(QPen(QColor("lightcoral")));
    Bar_Sort->setBrush(QColor("lightcoral"));
    Bar_Sort->setData(x, SortData);

    QCPLegend *legendMoney = new QCPLegend;
    MoneyAxisRect->insetLayout()->addElement(legendMoney, Qt::AlignTop | Qt::AlignHCenter);
    legendMoney->setLayer("legend");
    legendMoney->addItem(new QCPPlottableLegendItem(legendMoney, Bar_Money));
    Bar_Money->setName("Money: Round(0)");

    QCPLegend *legendSort = new QCPLegend;
    SortAxisRect->insetLayout()->addElement(legendSort, Qt::AlignTop | Qt::AlignHCenter);
    legendSort->setLayer("legend");
    legendSort->addItem(new QCPPlottableLegendItem(legendSort, Bar_Sort));
    Bar_Sort->setName("Money Sorted: Round(0)");

    //    customPlot->replot();
}

void PlotWidget::InitData(QVector<double> &obj)
{
    obj.fill(100, 100);
}

void PlotWidget::on_pushButton_go_clicked()
{
    if (go_flag == 0) {
        go_flag = 1;

        InitData(MoneyData);
        InitData(SortData);
        round = 0;

        timer->start(100);
        ui->pushButton_go->setText("Stop");
    } else if (go_flag == 1) {
        go_flag = 0;
        timer->stop();
        ui->pushButton_go->setText("Go");
    }
}

void PlotWidget::on_spinBox_step_valueChanged(int arg1)
{
    totalSteps = arg1;
}

void PlotWidget::on_comboBox_round_currentIndexChanged(int index)
{
    switch (index) {
    case 0:
        totalRounds = 1000;
        break;
    case 1:
        totalRounds = 1500;
        break;
    case 2:
        totalRounds = 2000;
        break;
    case 3:
        totalRounds = 2500;
        break;
    case 4:
        totalRounds = 3000;
        break;
    default:
        break;
    }
}

void PlotWidget::on_pushButton_reset_clicked()
{
    ui->comboBox_round->setCurrentIndex(1);
    ui->spinBox_step->setValue(10);
    ui->checkBox_same->setChecked(false);
    InitData(MoneyData);
    InitData(SortData);
    QVector<double> x(100);
    for (int i = 0; i < 100; i++) {
        x[i] = i;
    }
    Bar_Money->setData(x, MoneyData);
    Bar_Sort->setData(x, SortData);
    round = 0;
    Bar_Money->setName(QString("Money: Round(%1)").arg(round));
    Bar_Sort->setName(QString("Money Sorted: Round(%1)").arg(round));
    Bar_Money->setPen(QPen(QColor("lightblue")));
    Bar_Money->setBrush(QColor("lightblue"));
    Bar_Sort->setPen(QPen(QColor("lightcoral")));
    Bar_Sort->setBrush(QColor("lightcoral"));
    ui->widget->replot();

    color_Money = QColor("lightblue");
    color_Sort = QColor("lightcoral");

    ui->pushButton_color1->setStyleSheet("background-color: " + color_Money.name() + ";");
    ui->pushButton_color2->setStyleSheet("background-color: " + color_Sort.name() + ";");
}

void PlotWidget::on_pushButton_color1_clicked()
{
    color_Money = QColorDialog::getColor(Qt::white, this);
    qDebug() << "颜色选择" << color_Money << color_Money.name();
    if (!color_Money.isValid()) {
        return;
    } else {
        ui->pushButton_color1->setStyleSheet("background-color: " + color_Money.name() + ";");
        QRgb rgb = color_Money.rgb();
        qDebug() << "rgb== " << qRed(rgb) << qGreen(rgb) << qBlue(rgb);
        Bar_Money->setPen(QPen(QColor(color_Money)));
        Bar_Money->setBrush(QColor(color_Money));
        ui->widget->replot();
    }
    if (ui->checkBox_same->isChecked() == true) {
        color_Sort = color_Money;
        ui->pushButton_color2->setStyleSheet("background-color: " + color_Sort.name() + ";");
        Bar_Sort->setPen(QPen(QColor(color_Sort)));
        Bar_Sort->setBrush(QColor(color_Sort));
        ui->widget->replot();
    }
}

void PlotWidget::on_checkBox_same_stateChanged(int arg1)
{
    if (arg1 == Qt::Checked) {
        ui->pushButton_color2->setEnabled(false);
        color_Sort = color_Money;
        ui->pushButton_color2->setStyleSheet("background-color: " + color_Sort.name() + ";");
        Bar_Sort->setPen(QPen(QColor(color_Sort)));
        Bar_Sort->setBrush(QColor(color_Sort));
        ui->widget->replot();
    } else {
        ui->pushButton_color2->setEnabled(true);
    }
}

void PlotWidget::on_pushButton_color2_clicked()
{
    color_Sort = QColorDialog::getColor(Qt::white, this);
    qDebug() << "颜色选择" << color_Sort << color_Sort.name();
    if (!color_Sort.isValid()) {
        return;
    } else {
        ui->pushButton_color2->setStyleSheet("background-color: " + color_Sort.name() + ";");
        QRgb rgb = color_Sort.rgb();
        qDebug() << "rgb== " << qRed(rgb) << qGreen(rgb) << qBlue(rgb);
        Bar_Sort->setPen(QPen(QColor(color_Sort)));
        Bar_Sort->setBrush(QColor(color_Sort));
        ui->widget->replot();
    }
}
