#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void readImage();

    QTcpServer *tcpserver;
    QTcpSocket *tcpsocket;
    int totalsize;
    QByteArray jpgArr;
    int flag_camera_open = 0;

    QList<QTcpSocket *> clientSockets;

private slots:
    void on_pushButton_server_clicked();

    void on_pushButton_send_clicked();

    void on_pushButton_camera_clicked();

    void on_pushButton_shoot_clicked();

    void on_pushButton_save_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
