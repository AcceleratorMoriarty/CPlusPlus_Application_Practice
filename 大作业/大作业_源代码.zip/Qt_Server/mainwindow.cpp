#include "mainwindow.h"
#include <QTime>
#include <QTimer>
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->widget_light->SetLightColor(LightWgt::bRed);
    ui->pushButton_shoot->setDisabled(true);
    ui->pushButton_save->setDisabled(true);

    tcpserver = new QTcpServer(this);
    tcpsocket = new QTcpSocket(this);

    //服务器建立连接
    connect(tcpserver, &QTcpServer::newConnection, this, [=]() {
        QTcpSocket *newClientSocket = tcpserver->nextPendingConnection();
        clientSockets.append(newClientSocket);

        connect(newClientSocket, &QTcpSocket::readyRead, this, &MainWindow::readImage);
        connect(newClientSocket, &QTcpSocket::disconnected, this, [=]() {
            clientSockets.removeOne(newClientSocket);
            newClientSocket->deleteLater();
            ui->widget_light->SetLightColor(LightWgt::bRed);
            ui->label_state->setText("未连接");
        });
        ui->widget_light->SetLightColor(LightWgt::bGreen);
        ui->label_state->setText("已连接");
    });
}
void MainWindow::readImage()
{
    if (ui->checkBox_1->isChecked()) {
        QByteArray buf = clientSockets[0]->readAll();

        //    ui->textEdit_record->append("服务器say:" + buf);

        if (buf.contains("size=")) {
            //"size=30711"的30711直接把size=这个字符串删掉
            buf = buf.replace("size=", "");

            totalsize = buf.toInt(); //定义一个变量来接收数据大小，用于下面比较

            jpgArr.clear();

        } else {
            jpgArr.append(buf); //如果不是图片大小数据，就是图片数据，图片数据追加写到数组里面
        }

        if (jpgArr.length() == totalsize) {
            QPixmap pixmap;
            if (pixmap.loadFromData(jpgArr, "JPG")) {
                // 如果图像成功加载
                ui->label_camera->setPixmap(pixmap.scaled(ui->label_camera->size(),
                                                          Qt::IgnoreAspectRatio,
                                                          Qt::SmoothTransformation));
            }
            jpgArr.clear();
            totalsize = 0;
        }
    }

    if (ui->checkBox_2->isChecked()) {
        QByteArray buf = clientSockets[1]->readAll();

        //    ui->textEdit_record->append("服务器say:" + buf);

        if (buf.contains("size=")) {
            //"size=30711"的30711直接把size=这个字符串删掉
            buf = buf.replace("size=", "");

            totalsize = buf.toInt(); //定义一个变量来接收数据大小，用于下面比较

            jpgArr.clear();

        } else {
            jpgArr.append(buf); //如果不是图片大小数据，就是图片数据，图片数据追加写到数组里面
        }

        if (jpgArr.length() == totalsize) {
            QPixmap pixmap;
            if (pixmap.loadFromData(jpgArr, "JPG")) {
                // 如果图像成功加载
                ui->label_camera_2->setPixmap(pixmap.scaled(ui->label_camera_2->size(),
                                                            Qt::IgnoreAspectRatio,
                                                            Qt::SmoothTransformation));
            }
            jpgArr.clear();
            totalsize = 0;
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_server_clicked()
{
    tcpserver->listen(QHostAddress::Any, ui->lineEdit_port->text().toUInt());
    qDebug() << "服务器已打开";
    ui->pushButton_server->setDisabled(true);
}

void MainWindow::on_pushButton_send_clicked()
{
    QString msg = ui->textEdit_send->toPlainText();
    if (ui->checkBox_1->isChecked()) {
        clientSockets[0]->write(msg.toUtf8());
    }
    if (ui->checkBox_2->isChecked()) {
        clientSockets[1]->write(msg.toUtf8());
    }
    ui->textEdit_record->append("服务器:" + msg);
}

void MainWindow::on_pushButton_camera_clicked()
{
    QString msg;
    if (flag_camera_open == 0) {
        ui->pushButton_camera->setText("关闭摄像头");
        ui->pushButton_shoot->setDisabled(false);
        ui->pushButton_save->setDisabled(false);
        msg = "pB_camera_clicked1";
        if (ui->checkBox_1->isChecked()) {
            clientSockets[0]->write(msg.toUtf8());
            ui->textEdit_record->append("服务器0:" + msg);
        }
        if (ui->checkBox_2->isChecked()) {
            clientSockets[1]->write(msg.toUtf8());
            ui->textEdit_record->append("服务器1:" + msg);
        }

        flag_camera_open = 1;
    } else {
        ui->pushButton_camera->setText("打开摄像头");
        ui->pushButton_shoot->setDisabled(true);
        ui->pushButton_save->setDisabled(true);
        msg = "pB_camera_clicked2";
        if (ui->checkBox_1->isChecked()) {
            clientSockets[0]->write(msg.toUtf8());
            ui->textEdit_record->append("服务器0:" + msg);
        }
        if (ui->checkBox_2->isChecked()) {
            clientSockets[1]->write(msg.toUtf8());
            ui->textEdit_record->append("服务器1:" + msg);
        }
        flag_camera_open = 0;
    }
}

void MainWindow::on_pushButton_shoot_clicked()
{
    QString msg = "pB_shoot_clicked";
    if (ui->checkBox_1->isChecked()) {
        clientSockets[0]->write(msg.toUtf8());
        ui->textEdit_record->append("服务器0:" + msg);
    }
    if (ui->checkBox_2->isChecked()) {
        clientSockets[1]->write(msg.toUtf8());
        ui->textEdit_record->append("服务器1:" + msg);
    }
}

void MainWindow::on_pushButton_save_clicked()
{
    QString msg = "pB_save_clicked";
    if (ui->checkBox_1->isChecked()) {
        clientSockets[0]->write(msg.toUtf8());
        ui->textEdit_record->append("服务器0:" + msg);
    }
    if (ui->checkBox_2->isChecked()) {
        clientSockets[1]->write(msg.toUtf8());
        ui->textEdit_record->append("服务器1:" + msg);
    }
}
