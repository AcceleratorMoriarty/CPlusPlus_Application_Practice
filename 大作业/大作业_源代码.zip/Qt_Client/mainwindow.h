#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include "matlabel.h"
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
using namespace std;
using namespace cv;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void HSV_threshold(Mat inputimg, MatLabel *label);

public slots:
    void Slot_H_l_Changed(int value);
    void Slot_H_h_Changed(int value);
    void Slot_S_l_Changed(int value);
    void Slot_S_h_Changed(int value);
    void Slot_V_l_Changed(int value);
    void Slot_V_h_Changed(int value);

private slots:
    void video_update();

    void on_pushButton_open_clicked();

    void on_pushButton_shoot_clicked();

    void on_pushButton_save_clicked();

    void on_pushButton_send_clicked();

    void on_pushButton_connect_clicked();

    void on_pushButton_disconnect_clicked();

private:
    Ui::MainWindow *ui;

    Mat cameraimg, grayimg, shootimg, hsvimg, detectimg;

    VideoCapture cap;
    QTimer *timer; //计时器
    int flag_camera_open = 0;
    int flag_img_shot = 0;

    CascadeClassifier face_cascade; //载入分类器
    vector<Rect> faceRect;
    vector<Rect> faces;

    int H_l = 0, S_l = 0, V_l = 0, H_h = 180, S_h = 255, V_h = 255;

    QTcpSocket *m_tcp;
};
#endif // MAINWINDOW_H
