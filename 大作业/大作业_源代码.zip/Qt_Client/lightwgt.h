#ifndef LIGHTWGT_H
#define LIGHTWGT_H

#include <QWidget>

class LightWgt : public QWidget
{
    Q_OBJECT

public:
    explicit LightWgt(QWidget *parent = 0);

protected:
    void paintEvent(QPaintEvent *);
    void drawBorderOut(QPainter *painter);
    void drawBorderIn(QPainter *painter);
    void drawBg(QPainter *painter);
    void drawOverlay(QPainter *painter);

private:
    QColor borderOutColorStart; //外边框渐变开始颜色
    QColor borderOutColorEnd;   //外边框渐变结束颜色
    QColor borderInColorStart;  //里边框渐变开始颜色
    QColor borderInColorEnd;    //里边框渐变结束颜色
    QColor overlayColor;        //遮罩层颜色

    uint8_t c;

public:
    //定义颜色枚举变量
    enum LightColors { bRed, bGreen, bYellow, bGray };

    void setrgColor(QRadialGradient *rg);
    void SetLightColor(enum LightColors color);
};
#endif // LIGHTWGT_H
