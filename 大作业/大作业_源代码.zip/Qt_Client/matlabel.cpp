#include "matlabel.h"
#include <QDebug>

MatLabel::MatLabel(QWidget *parent) : QLabel(parent) {

  setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
  setText("");
}

MatLabel::~MatLabel() {}

QImage MatLabel::Mat2QImage(const cv::Mat &mat) {

  cv::Mat tmp;
  QImage::Format imageColorFormat;
  switch (mat.channels()) {
  case IMG_CHANNEL_SINGLE:
    imageColorFormat = QImage::Format_Indexed8;
    tmp = mat;
    break;
  case IMG_CHANNEL_TRIPLE:
    imageColorFormat = QImage::Format_RGB888;
    cv::cvtColor(mat, tmp, cv::COLOR_BGR2RGB);
    break;
  default:
    imageColorFormat = QImage::Format_RGB888;
    cv::cvtColor(mat, tmp, cv::COLOR_BGR2RGB);
    break;
  }
  QImage dest(static_cast<const quint8 *>(tmp.data), tmp.cols, tmp.rows, int(tmp.step), imageColorFormat);

  // 必须进行深拷贝，否则挂掉没商量
  dest.bits();

  return dest;
}

cv::Mat MatLabel::QImage2Mat(const QImage &src) {
  int color = 0;
  switch (src.format()) {
  case QImage::Format_Mono:
    color = CV_8UC1;        // CV_8UC(src.depth());
    break;
  case QImage::Format_RGB888:
    color = CV_8UC3;        // CV_8UC(src.depth());
    break;
  default: color = CV_8UC3;
  }
  cv::Mat tmp(src.height(), src.width(), color, const_cast<uchar *>(src.bits()),
              static_cast<size_t>(src.bytesPerLine()));
  // deep copy just in case (my lack of knowledge with open cv)
  cv::Mat result;        // deep copy just in case (my lack of knowledge with open cv)
  cv::cvtColor(tmp, result, cv::COLOR_RGB2BGR);
  return result;
}

void MatLabel::updateBackground(const cv::Mat &background, bool keepRatio) {

  if (background.empty()) {
    qDebug() << "背景为空!";
    return;
  }

  QImage img = MatLabel::Mat2QImage(background);
  QPixmap bg = QPixmap::fromImage(img);
  if (keepRatio) {
    bg = bg.scaled(size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
  } else {
    bg = bg.scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
  }

  setPixmap(bg);
}

QSize MatLabel::sizeHint() const { return QSize(10, 10); }
