#include "mainwindow.h"
#include <QBuffer>
#include <QFileDialog>
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->pushButton_save->setDisabled(true);
    ui->pushButton_shoot->setDisabled(true);
    ui->widget_light->SetLightColor(LightWgt::bRed);
    connect(ui->widget_Slider, &SliderWidget::H_l_Changed, this, &MainWindow::Slot_H_l_Changed);
    connect(ui->widget_Slider, &SliderWidget::H_h_Changed, this, &MainWindow::Slot_H_h_Changed);
    connect(ui->widget_Slider, &SliderWidget::S_l_Changed, this, &MainWindow::Slot_S_l_Changed);
    connect(ui->widget_Slider, &SliderWidget::S_h_Changed, this, &MainWindow::Slot_S_h_Changed);
    connect(ui->widget_Slider, &SliderWidget::V_l_Changed, this, &MainWindow::Slot_V_l_Changed);
    connect(ui->widget_Slider, &SliderWidget::V_h_Changed, this, &MainWindow::Slot_V_h_Changed);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::video_update);

    m_tcp = new QTcpSocket;
    connect(m_tcp, &QTcpSocket::readyRead, this, [=]() {
        QByteArray data = m_tcp->readAll();
        ui->textEdit_record->append("服务器:" + data);

        if (data == "pB_camera_clicked1") {
            flag_camera_open = 0;
            on_pushButton_open_clicked();
        } else if (data == "pB_camera_clicked2") {
            flag_camera_open = 1;
            on_pushButton_open_clicked();
        } else if (data == "pB_shoot_clicked") {
            on_pushButton_shoot_clicked();
        } else if (data == "pB_save_clicked") {
            on_pushButton_save_clicked();
        }
    });
    connect(m_tcp, &QTcpSocket::disconnected, this, [=]() {
        m_tcp->close();
        ui->widget_light->SetLightColor(LightWgt::bRed);
        ui->textEdit_record->append("服务器已经和客户端断开连接");
        ui->label_state->setText("未连接");
        ui->pushButton_connect->setDisabled(false);
        ui->pushButton_disconnect->setEnabled(false);
    });
    connect(m_tcp, &QTcpSocket::connected, this, [=]() {
        ui->widget_light->SetLightColor(LightWgt::bGreen);
        ui->textEdit_record->append("已经成功连接到服务器");
        ui->label_state->setText("已连接");
        ui->pushButton_connect->setDisabled(true);
        ui->pushButton_disconnect->setEnabled(true);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

//摄像头界面显示
void MainWindow::video_update()
{
    cap >> cameraimg;

    // 镜像处理，水平翻转
    cv::flip(cameraimg, cameraimg, 1);

    if (!cameraimg.empty()) //判断当前帧是否捕捉成功
    {
        if (ui->radioButton_face->isChecked()) {
            cvtColor(cameraimg, grayimg, COLOR_BGR2GRAY); //转为灰度图
            equalizeHist(grayimg, grayimg); //直方图均衡化，增加对比度方便处理

            if (!face_cascade.load(
                    "D:\\Software\\Qt_Extend\\opencv_4_8_"
                    "0\\sources\\data\\haarcascades\\haarcascade_frontalface_alt.xml")) {
                qDebug("Load haarcascade_frontalface_alt failed!");
                return;
            }
            //检测关于脸部位置
            face_cascade.detectMultiScale(grayimg,
                                          faceRect,
                                          1.1,
                                          2,
                                          0 | CASCADE_SCALE_IMAGE,
                                          Size(30, 30)); //检测
            for (size_t i = 0; i < faceRect.size(); i++) {
                rectangle(cameraimg, faceRect[i], Scalar(0, 255, 0)); //用绿色矩形画出检测到的位置
            }
            ui->label_cap->updateBackground(cameraimg);
        }
        if (ui->radioButton_HSV->isChecked()) {
            ui->label_cap->updateBackground(cameraimg);
        }
        if (ui->radioButton_detect->isChecked()) {
            cvtColor(cameraimg, detectimg, cv::COLOR_BGR2HSV);
            inRange(detectimg, Scalar(H_l, S_l, V_l), Scalar(H_h, S_h, V_h), detectimg);
            // 寻找轮廓
            std::vector<std::vector<cv::Point>> contours;
            findContours(detectimg, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

            // 遍历轮廓并在原图上绘制矩形框
            for (size_t i = 0; i < contours.size(); i++) {
                Rect rect = boundingRect(contours[i]);
                if (contourArea(contours[i]) > ui->lineEdit_area->text().toInt()) {
                    rectangle(cameraimg, rect, Scalar(0, 255, 0), 2); // 用绿色矩形框出轮廓
                }
            }

            ui->label_cap->updateBackground(cameraimg);
        }

        /***************图像传输*****************/
        if (m_tcp->state() == QAbstractSocket::ConnectedState) {
            Mat outimg;
            cvtColor(cameraimg, outimg, cv::COLOR_BGR2RGB);
            QImage image(outimg.data, outimg.cols, outimg.rows, outimg.step, QImage::Format_RGB888);
            QPixmap pixmap = QPixmap::fromImage(image);
            QByteArray ba;
            QBuffer buf(&ba);
            pixmap.save(&buf, "JPG");

            // 保存图像到文件（用于调试）
            QString debugFilename = "debug_image.jpg";
            pixmap.save(debugFilename);

            qDebug() << "发送图像大小：" << ba.size();
            m_tcp->write(QString("size=%1").arg(ba.size()).toLocal8Bit().data());
            m_tcp->write(ba); // 直接写入图像数据
        }

    } else
        qDebug("Camera frame is empty.");
}

//打开关闭摄像头
void MainWindow::on_pushButton_open_clicked()
{
    if (flag_camera_open == 0) {
        cap.open(0);
        timer->start(30);
        ui->pushButton_open->setText("关闭摄像头");
        ui->pushButton_shoot->setDisabled(false);
        ui->pushButton_save->setDisabled(false);
        flag_camera_open = 1;
    } else {
        timer->stop();
        cap.release();
        ui->label_cap->clear();
        ui->pushButton_open->setText("打开摄像头");
        ui->pushButton_save->setDisabled(true);
        ui->pushButton_shoot->setDisabled(true);
        flag_camera_open = 0;
    }
}

void MainWindow::on_pushButton_shoot_clicked()
{
    if (!cameraimg.empty() && flag_camera_open == 1) //判断当前帧是否捕捉成功
    {
        shootimg = cameraimg.clone();
        ui->label_shoot->updateBackground(shootimg);
        cvtColor(shootimg, hsvimg, cv::COLOR_BGR2HSV);
    }
}

void MainWindow::on_pushButton_save_clicked()
{
    if (shootimg.empty()) {
        qDebug() << "没有可保存的图像";
        return;
    }

    // 打开文件保存对话框
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("保存图片"),
                                                    "",
                                                    tr("Image Files (*.png *.jpg *.bmp)"));

    // 检查用户是否选择了文件
    if (fileName.isEmpty()) {
        return; // 用户取消了操作
    }

    // 将OpenCV的Mat对象转换为QImage
    QImage qimg;
    if (shootimg.type() == CV_8UC3) {
        qimg = QImage((const unsigned char *) (shootimg.data),
                      shootimg.cols,
                      shootimg.rows,
                      shootimg.step,
                      QImage::Format_RGB888)
                   .rgbSwapped();
    } else if (shootimg.type() == CV_8UC1) {
        qimg = QImage((const unsigned char *) (shootimg.data),
                      shootimg.cols,
                      shootimg.rows,
                      shootimg.step,
                      QImage::Format_Grayscale8);
    } else {
        qDebug() << "不支持的图像类型";
        return;
    }

    // 保存图像
    qimg.save(fileName);
}

void MainWindow::HSV_threshold(cv::Mat inputimg, MatLabel *label)
{
    if (ui->radioButton_HSV->isChecked()) {
        Mat outimg;
        inRange(inputimg, cv::Scalar(H_l, S_l, V_l), cv::Scalar(H_h, S_h, V_h), outimg);
        label->updateBackground(outimg);
    }
}

void MainWindow::Slot_H_l_Changed(int value)
{
    H_l = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}
void MainWindow::Slot_H_h_Changed(int value)
{
    H_h = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}
void MainWindow::Slot_S_l_Changed(int value)
{
    S_l = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}
void MainWindow::Slot_S_h_Changed(int value)
{
    S_h = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}
void MainWindow::Slot_V_l_Changed(int value)
{
    V_l = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}
void MainWindow::Slot_V_h_Changed(int value)
{
    V_h = value;
    HSV_threshold(hsvimg, ui->label_shoot);
}

void MainWindow::on_pushButton_send_clicked()
{
    QString msg = ui->textEdit_send->toPlainText();
    m_tcp->write(msg.toUtf8());
    ui->textEdit_record->append("客户端:" + msg);
}

void MainWindow::on_pushButton_connect_clicked()
{
    QString ip = ui->lineEdit_ip->text();
    quint16 port = ui->lineEdit_port->text().toUInt();
    m_tcp->connectToHost(QHostAddress(ip), port);
}

void MainWindow::on_pushButton_disconnect_clicked()
{
    m_tcp->close();
    ui->widget_light->SetLightColor(LightWgt::bRed);
    ui->label_state->setText("未连接");
    ui->pushButton_connect->setDisabled(false);
    ui->pushButton_disconnect->setEnabled(false);
}
