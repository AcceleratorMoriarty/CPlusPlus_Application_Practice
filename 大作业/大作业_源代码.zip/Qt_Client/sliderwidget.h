#ifndef SLIDERWIDGET_H
#define SLIDERWIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class SliderWidget; }
QT_END_NAMESPACE

class SliderWidget : public QWidget
{
    Q_OBJECT

public:
    SliderWidget(QWidget *parent = nullptr);
    ~SliderWidget();

private slots:
    void on_horizontalSlider_LowH_valueChanged(int value);
    void on_horizontalSlider_HighH_valueChanged(int value);
    void on_horizontalSlider_LowS_valueChanged(int value);
    void on_horizontalSlider_HighS_valueChanged(int value);
    void on_horizontalSlider_LowV_valueChanged(int value);
    void on_horizontalSlider_HighV_valueChanged(int value);

    void on_pushButton_reset_clicked();

signals:
    void H_l_Changed(int value);
    void H_h_Changed(int value);
    void S_l_Changed(int value);
    void S_h_Changed(int value);
    void V_l_Changed(int value);
    void V_h_Changed(int value);

private:
    Ui::SliderWidget *ui;

    //默认初始化值
    int LowH = 0;
    int HighH = 180;
    int LowS = 0;
    int HighS = 255;
    int LowV = 0;
    int HighV = 255;
};
#endif // SLIDERWIDGET_H
