#ifndef OPENCVLABEL_H
#define OPENCVLABEL_H

#include <QLabel>

#include <opencv2/core.hpp>

#include <opencv2/imgproc.hpp>

class MatLabel : public QLabel {
  Q_OBJECT
public:
  explicit MatLabel(QWidget *parent = nullptr);
  ~MatLabel();

public slots:
  void updateBackground(const cv::Mat &background, bool keepRatio = false);

protected:
  static QImage Mat2QImage(cv::Mat const &mat);
  static cv::Mat QImage2Mat(const QImage &src);

private:
  enum IMG_CHANNELS {
    IMG_CHANNEL_SINGLE = 1,
    IMG_CHANNEL_TRIPLE = 3,
  };

private:
  cv::Mat currentBackground;

    // QWidget interface
public:
    virtual QSize sizeHint() const override;
};

#endif        // OPENCVLABEL_H
