#include "hsvwidget.h"
#include "ui_hsvwidget.h"
#include <hsvwidget.h>

#include <QDebug>

HsvWidget::HsvWidget(QWidget *parent) : QWidget(parent), ui(new Ui::HsvWidget) {
  ui->setupUi(this);

  mat = cv::imread("res/circles.png", cv::IMREAD_COLOR);
  cv::cvtColor(mat, hsv, cv::COLOR_BGR2HSV);
  cv::inRange(hsv, cv::Scalar(0, 0, 0), cv::Scalar(180, 255, 255), inranged);
  //  hsv = mat.clone();

  connect(ui->optionsWidget, &HsvOptionsWidget::hsvValueRangeChanged, this, &HsvWidget::onHsvValueRangeChanged);
}

HsvWidget::~HsvWidget() { delete ui; }

void HsvWidget::onHsvValueRangeChanged(const HsvValueRange &newRange) {
  cv::Mat frame;

  cv::cvtColor(mat, frame, cv::COLOR_BGR2HSV);

  cv::inRange(frame, cv::Scalar(newRange.getLowHue(), newRange.getLowSaturation(), newRange.getLowValue()),
              cv::Scalar(newRange.getHighHue(), newRange.getHighSaturation(), newRange.getHighValue()), inranged);

  updateImages();
}

void HsvWidget::updateImages() {
  ui->lbSource->updateBackground(mat);
  ui->lbInRanged->updateBackground(inranged);
  ui->lbHsv->updateBackground(hsv);
}

void HsvWidget::resizeEvent(QResizeEvent *event) {
  updateImages();
  QWidget::resizeEvent(event);
}
