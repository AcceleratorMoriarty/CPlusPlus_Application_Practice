#ifndef HSVOPTIONSWIDGET_H
#define HSVOPTIONSWIDGET_H

#include <QWidget>

#include <QMetaType>

QT_BEGIN_NAMESPACE
namespace Ui {
class OpenCVOptionsWidget;
}
QT_END_NAMESPACE

/**
 * @brief The HsvValueRange class
 * @date
 * @details 该类为一个集中设置HSV各通道数值的数据类，是HsvOptionsWidget的辅助类
 *          该类向元对象系统注册，使之可以用于信号槽参数传输
 */
class HsvValueRange {

public:
  HsvValueRange() = default;
  ~HsvValueRange() = default;
  HsvValueRange(const HsvValueRange &) = default;
  HsvValueRange &operator=(const HsvValueRange &) = default;

  //  void operator=(const HsvValueRange &other);
  friend bool operator==(const HsvValueRange &first, const HsvValueRange &second);

  int getLowHue() const;
  void setLowHue(int newLowHue);

  int getHighHue() const;
  void setHighHue(int newHighHue);

  int getLowSaturation() const;
  void setLowSaturation(int newLowSaturation);

  int getHighSaturation() const;
  void setHighSaturation(int newHighSaturation);

  int getLowValue() const;
  void setLowValue(int newLowValue);

  int getHighValue() const;
  void setHighValue(int newHighValue);

private:
  // 默认初始化参数，在创建对象时，作为各参数的默认值
  int lowHue = 0;
  int highHue = 180;
  int lowSaturation = 0;
  int highSaturation = 255;
  int lowValue = 0;
  int highValue = 255;
};

/**
 * @brief The HsvOptionsWidget class
 * @details 该类对应于hsv滑动条窗口，暂开放一个参数改变信号，用户改变滑动条参数时，发送hsvValueRangeChanged信号
 *          使用者直接响应该信号即可。
 *          该窗口类内置2个pushButton，目前使用reset按键以便复位参数，另一个按键暂未使用。
 */
class HsvOptionsWidget : public QWidget {
  Q_OBJECT

  Q_PROPERTY(HsvValueRange hsvValueRange READ hsvValueRange WRITE setHsvValueRange NOTIFY hsvValueRangeChanged FINAL)

public:
  HsvOptionsWidget(QWidget *parent = nullptr);
  ~HsvOptionsWidget();

  HsvValueRange hsvValueRange() const;
  void setHsvValueRange(const HsvValueRange &newHsvValueRange);

signals:
  void hsvValueRangeChanged(const HsvValueRange &newRange);
  void resetHsv();          // 该信号在用户按下 复位hsv参数 按键时发射
  void resetImage();        // 该信号在用户按下 复位图像 按键时发射

protected slots:
  void onBtnResetClicked();

private:
  Ui::OpenCVOptionsWidget *ui;
  HsvValueRange m_hsvValueRange;
};

Q_DECLARE_METATYPE(HsvValueRange);
#endif        // HSVOPTIONSWIDGET_H
