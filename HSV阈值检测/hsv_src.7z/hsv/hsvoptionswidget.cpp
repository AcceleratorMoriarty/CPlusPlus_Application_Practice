#include "hsvoptionswidget.h"
#include "ui_hsvoptionswidget.h"
#include <QSignalMapper>
#include <QSlider>

int HsvValueRange::getLowHue() const { return lowHue; }

void HsvValueRange::setLowHue(int newLowHue) { lowHue = newLowHue; }

int HsvValueRange::getHighHue() const { return highHue; }

void HsvValueRange::setHighHue(int newHighHue) { highHue = newHighHue; }

int HsvValueRange::getLowSaturation() const { return lowSaturation; }

void HsvValueRange::setLowSaturation(int newLowSaturation) { lowSaturation = newLowSaturation; }

int HsvValueRange::getHighSaturation() const { return highSaturation; }

void HsvValueRange::setHighSaturation(int newHighSaturation) { highSaturation = newHighSaturation; }

int HsvValueRange::getLowValue() const { return lowValue; }

void HsvValueRange::setLowValue(int newLowValue) { lowValue = newLowValue; }

int HsvValueRange::getHighValue() const { return highValue; }

void HsvValueRange::setHighValue(int newHighValue) { highValue = newHighValue; }

bool operator==(const HsvValueRange &first, const HsvValueRange &second) {
  bool result = first.lowHue == second.lowHue;
  result &= (first.highHue == second.highHue);
  result &= (first.lowSaturation == second.lowSaturation);
  result &= (first.highSaturation == second.highSaturation);
  result &= (first.lowValue == second.lowValue);
  result &= (first.highValue == second.highValue);
  return result;
}

HsvOptionsWidget::HsvOptionsWidget(QWidget *parent) : QWidget(parent), ui(new Ui::OpenCVOptionsWidget) {
  ui->setupUi(this);

  connect(ui->btnResetHsv, &QPushButton::clicked, this, [this]() { emit resetHsv(); });
  connect(ui->btnResetImage, &QPushButton::clicked, this, [this]() { emit resetImage(); });

  connect(ui->sliderHighHue, &QSlider::valueChanged, this, [this](int value) {
    ui->lbHighH->setText(QString("%1/180").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setHighHue(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
  connect(ui->sliderLowHue, &QSlider::valueChanged, this, [this](int value) {
    ui->lbLowH->setText(QString("%1/180").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setLowHue(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
  connect(ui->sliderHighSaturation, &QSlider::valueChanged, this, [this](int value) {
    ui->lbHighS->setText(QString("%1/255").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setHighSaturation(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
  connect(ui->sliderLowSaturation, &QSlider::valueChanged, this, [this](int value) {
    ui->lbLowS->setText(QString("%1/255").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setLowSaturation(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
  connect(ui->sliderHighValue, &QSlider::valueChanged, this, [this](int value) {
    ui->lbHighV->setText(QString("%1/255").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setHighValue(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
  connect(ui->sliderLowValue, &QSlider::valueChanged, this, [this](int value) {
    ui->lbLowV->setText(QString("%1/255").arg(value, 3, 10, QChar('0')));
    m_hsvValueRange.setLowValue(value);
    emit hsvValueRangeChanged(m_hsvValueRange);
  });
}

HsvOptionsWidget::~HsvOptionsWidget() { delete ui; }

HsvValueRange HsvOptionsWidget::hsvValueRange() const { return m_hsvValueRange; }

void HsvOptionsWidget::setHsvValueRange(const HsvValueRange &newHsvValueRange) {
  if (m_hsvValueRange == newHsvValueRange)
    return;
  m_hsvValueRange = newHsvValueRange;
  emit hsvValueRangeChanged(newHsvValueRange);
}

void HsvOptionsWidget::onBtnResetClicked() {
  HsvValueRange defaultRange;
  ui->sliderLowValue->setValue(defaultRange.getLowValue());
  ui->sliderHighValue->setValue(defaultRange.getHighValue());
  ui->sliderLowSaturation->setValue(defaultRange.getLowSaturation());
  ui->sliderHighSaturation->setValue(defaultRange.getHighSaturation());
  ui->sliderLowHue->setValue(defaultRange.getLowHue());
  ui->sliderHighHue->setValue(defaultRange.getHighHue());
  setHsvValueRange(defaultRange);
}
