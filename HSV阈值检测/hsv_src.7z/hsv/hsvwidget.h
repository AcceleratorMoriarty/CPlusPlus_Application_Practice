#ifndef HSVWIDGET_H
#define HSVWIDGET_H

#include <QWidget>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui {
class HsvWidget;
}
QT_END_NAMESPACE

class HsvValueRange;

class HsvWidget : public QWidget {
  Q_OBJECT

public:
  HsvWidget(QWidget *parent = nullptr);
  ~HsvWidget();

public slots:
  void onHsvValueRangeChanged(const HsvValueRange &newRange);

private:
  Ui::HsvWidget *ui;

  cv::Mat mat;
  cv::Mat inranged;
  cv::Mat hsv;

protected:
  void updateImages();

  // QWidget interface
protected:
  virtual void resizeEvent(QResizeEvent *event) override;
};
#endif        // HSVWIDGET_H
