#include <QApplication>
#include <QChart>
#include <QChartView>
#include "mymainwidget.h"
#include "sliderwidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MymainWidget w;
    w.show();
    return a.exec();
}
