#include "mymainwidget.h"
#include "sliderwidget.h"
#include "ui_mymainwidget.h"

MymainWidget::MymainWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MymainWidget)
{
    ui->setupUi(this);
    connect(ui->widget, SIGNAL(H_l_Changed(int)), SLOT(Slot_H_l_Changed(int)));
    connect(ui->widget, SIGNAL(H_h_Changed(int)), SLOT(Slot_H_h_Changed(int)));
    connect(ui->widget, SIGNAL(S_l_Changed(int)), SLOT(Slot_S_l_Changed(int)));
    connect(ui->widget, SIGNAL(S_h_Changed(int)), SLOT(Slot_S_h_Changed(int)));
    connect(ui->widget, SIGNAL(V_l_Changed(int)), SLOT(Slot_V_l_Changed(int)));
    connect(ui->widget, SIGNAL(V_h_Changed(int)), SLOT(Slot_V_h_Changed(int)));

    //显示原始图像
    QPixmap pixmap(":/circles.png");
    img = pixmap.toImage();
    img = img.scaled(ui->label->width(), ui->label->height());
    ui->label->setPixmap(QPixmap::fromImage(img).scaled(ui->label->size(),
                                                        Qt::KeepAspectRatio,
                                                        Qt::SmoothTransformation));

    //显示HSV格式图像
    cv::Mat inputImage(img.height(), img.width(), CV_8UC4, img.bits(), img.bytesPerLine());
    cv::cvtColor(inputImage, hsvimg, cv::COLOR_BGR2HSV);
    imageshow(hsvimg, ui->label_src);

}

//Mat转QImage并显示在QLable上
void MymainWidget::imageshow(cv::Mat inputimg, QLabel *label)
{
    cv::Mat img;
    cv::cvtColor(inputimg, img, cv::COLOR_BGR2RGB);
    QImage outputimg(img.data, img.cols, img.rows, img.step, QImage::Format_RGB888);
    outputimg = outputimg.scaled(label->width(), label->height());
    label->setPixmap(QPixmap::fromImage(outputimg).scaled(label->size(),
                                                          Qt::KeepAspectRatio,
                                                          Qt::SmoothTransformation));
}

void MymainWidget::HSV_threshold(cv::Mat inputimg, QLabel *label)
{
    cv::Mat outimg;
    cv::inRange(inputimg, cv::Scalar(H_l, S_l, V_l), cv::Scalar(H_h, S_h, V_h), outimg);
    imageshow(outimg, label);
}

MymainWidget::~MymainWidget()
{
    delete ui;
}

void MymainWidget::Slot_H_l_Changed(int value)
{
    H_l = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
void MymainWidget::Slot_H_h_Changed(int value)
{
    H_h = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
void MymainWidget::Slot_S_l_Changed(int value)
{
    S_l = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
void MymainWidget::Slot_S_h_Changed(int value)
{
    S_h = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
void MymainWidget::Slot_V_l_Changed(int value)
{
    V_l = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
void MymainWidget::Slot_V_h_Changed(int value)
{
    V_h = value;
    HSV_threshold(hsvimg, ui->label_hsv);
}
