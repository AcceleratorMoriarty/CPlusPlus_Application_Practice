#include "sliderwidget.h"
#include "ui_sliderwidget.h"

SliderWidget::SliderWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SliderWidget)
{
    ui->setupUi(this);
}

SliderWidget::~SliderWidget()
{
    delete ui;
}

void SliderWidget::on_horizontalSlider_LowH_valueChanged(int value)
{
    emit H_l_Changed(value);
}

void SliderWidget::on_horizontalSlider_HighH_valueChanged(int value)
{
    emit H_h_Changed(value);
}

void SliderWidget::on_horizontalSlider_LowS_valueChanged(int value)
{
    emit S_l_Changed(value);
}

void SliderWidget::on_horizontalSlider_HighS_valueChanged(int value)
{
    emit S_h_Changed(value);
}

void SliderWidget::on_horizontalSlider_LowV_valueChanged(int value)
{
    emit V_l_Changed(value);
}

void SliderWidget::on_horizontalSlider_HighV_valueChanged(int value)
{
    emit V_h_Changed(value);
}
