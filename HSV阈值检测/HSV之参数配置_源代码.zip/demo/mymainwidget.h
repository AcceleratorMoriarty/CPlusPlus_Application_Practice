#ifndef MYMAINWIDGET_H
#define MYMAINWIDGET_H

#include <QLabel>
#include <QWidget>
#include <opencv2/opencv.hpp>

QT_BEGIN_NAMESPACE
namespace Ui { class MymainWidget; }
QT_END_NAMESPACE

class MymainWidget : public QWidget
{
    Q_OBJECT

public:
    MymainWidget(QWidget *parent = nullptr);
    ~MymainWidget();
    void imageshow(cv::Mat inputimg, QLabel *label);
    void HSV_threshold(cv::Mat inputimg, QLabel *label);
public slots:
    void Slot_H_l_Changed(int value);
    void Slot_H_h_Changed(int value);
    void Slot_S_l_Changed(int value);
    void Slot_S_h_Changed(int value);
    void Slot_V_l_Changed(int value);
    void Slot_V_h_Changed(int value);

private:
    Ui::MymainWidget *ui;
    QImage img;
    cv::Mat hsvimg;
    int H_l = 0, S_l = 0, V_l = 0, H_h = 180, S_h = 255, V_h = 255;
};
#endif // MYMAINWIDGET_H
