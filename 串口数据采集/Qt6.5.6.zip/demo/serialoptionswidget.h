#ifndef SERIALOPTIONSWIDGET_H
#define SERIALOPTIONSWIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class SerialOptionsWidget;
}
QT_END_NAMESPACE

class QSerialPort;
class QTimer;

class SerialOptionsWidget : public QWidget {
  Q_OBJECT

public:
  SerialOptionsWidget(QWidget *parent = nullptr);
  ~SerialOptionsWidget();

  signals:
  void serialDataReceived(const QString &data);
  void PlotDataReceived(const QList<qreal> &data);

  protected:
  void setupUI();
  void detectSerialPorts();

  void updateSerialParams();
  void testSend();
  void createTest();

protected slots:
  void updateWidgetsStatus();
  void onSerialParamsChanged();

  void onBtnGoClicked();

  void onSerialReadyRead();
  void onSerialBytesWritten(quint64 bytes);
  void onSerialErrorOccurred();

  void msgLog(const QString &msg);

private:
  Ui::SerialOptionsWidget *ui;
  QSerialPort *mSerial;

  void connectSerialSlots();
  QTimer *timer;
  QByteArray dataReceived;
};
#endif        // SERIALOPTIONSWIDGET_H
