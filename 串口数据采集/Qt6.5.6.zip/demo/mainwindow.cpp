#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QGridLayout *layout = new QGridLayout;
    layout->addWidget(ui->widget_plot);
    ui->Plot->setLayout(layout);

    connect(ui->widget_option,
            &SerialOptionsWidget::serialDataReceived,
            this,
            &MainWindow::updateDataWidget);
    connect(ui->widget_option, &SerialOptionsWidget::PlotDataReceived, this, &MainWindow::PlotData);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateDataWidget(const QString &data)
{
    ui->plainTextEdit->appendPlainText(data);
}
void MainWindow::PlotData(const QList<qreal> &data)
{
    static qreal key = 0;
    ui->widget_plot->dataComming(key++, data);

    //    QString dataString;

    //    for (int i = 0; i < data.size(); ++i) {
    //        dataString += QString::number(data.at(i), 'f', 2); // 转换为字符串并保留两位小数
    //        if (i < data.size() - 1) {
    //            dataString += ", "; // 除了最后一个元素，其余后面都加上逗号和空格
    //        }
    //    }

    //    ui->plainTextEdit->appendPlainText(dataString);
}

void MainWindow::on_pushButton_clicked()
{
    ui->plainTextEdit->clear();
}
