#include "plotwidget.h"
#include "ui_plotwidget.h"
#include <QRandomGenerator>

PlotWidget::PlotWidget(QWidget *parent) : QWidget(parent), ui(new Ui::PlotWidget) {
  ui->setupUi(this);

  setupPlot();

  connect(this, &PlotWidget::channelCountChanged, this, &PlotWidget::onChannelCountChanged);

  setChannelCount(3);
  //  updatePlotData();
  // 此处为模拟数据
  //  timer = new QTimer(this);
  //  timer->setInterval(1000);
  //  connect(timer, &QTimer::timeout, this, [=]() {
  //    //      for (int ch=0;ch<nChannels;++ch){
  //    static auto key = QDateTime::currentDateTime();
  //    QList<qreal> d;
  //    for (int i = 0; i < channelCount(); ++i) {
  //      d << QRandomGenerator::global()->bounded(330) / 100.0;
  //    }
  //    this->dataComming(QDateTime::currentDateTime().toSecsSinceEpoch() - key.toSecsSinceEpoch(), d);
  //  });
  //  timer->start();
}

PlotWidget::~PlotWidget() { delete ui; }

void PlotWidget::updatePlotTitle(const QString &newTitle) {
  QCustomPlot *customPlot = ui->customPlot;
  auto grid = customPlot->plotLayout();
  QCPTextElement *element = qobject_cast<QCPTextElement *>(grid->element(0, 0));
  qDebug() << element->text();
  element->setText(newTitle);
}

void PlotWidget::updatePlotData() {

  QCustomPlot *customPlot = ui->customPlot;

  // generate some data:
  QVector<double> x(101), y(101);        // initialize with entries 0..100
  for (int i = 0; i < 101; ++i) {
    x[i] = i / 50.0 - 1;        // x goes from -1 to 1
    y[i] = x[i] * x[i];         // let's plot a quadratic function
  }

  qDebug() << ui->customPlot->graphCount();

  //  customPlot->graph(0)->setData(x, y);
  customPlot->xAxis->setLabel("X");
  customPlot->xAxis->setRange(-1, 1);
  customPlot->yAxis->setLabel("Y");
  customPlot->yAxis->setRange(0, 1);

  //  customPlot->graph(1)->setData(y, x);
  //  for (int i = 0; i < x.size(); ++i) {
  //    customPlot->graph(2)->addData(x.at(i) * x.at(i), y.at(i));
  //  }
}

void PlotWidget::addSingleSeries(const QString &seriesName, const QColor &seriesColor) {
  QCustomPlot *customPlot = ui->customPlot;
  customPlot->legend->setVisible(false);
  //  //    qDebug() << QColor::colorNames();
  //  QStringList namedColors = {"red", "navy", "lime", "purple", "darkred", "mediumvioletred", "lightseagreen",
  //  "sienna"};
  auto graph = customPlot->addGraph();
  graph->setName(seriesName);
  graph->setPen(seriesColor);

  customPlot->legend->setVisible(true);
}

void PlotWidget::dataComming(const qreal &key, const QList<qreal> data) {
  QCustomPlot *customPlot = ui->customPlot;
  for (int ch = 0; ch < channelCount(); ++ch) {
    customPlot->graph(ch)->addData(key, data.at(ch));
  }
  customPlot->xAxis->setRange(key, 50, Qt::AlignRight);
  customPlot->replot();
}

void PlotWidget::onChannelCountChanged(int newChannels) {
  QCustomPlot *customPlot = ui->customPlot;
  customPlot->clearGraphs();
  QStringList namedColors = {"red", "navy", "lime", "purple", "darkred", "mediumvioletred", "lightseagreen", "sienna"};
  for (int ch = 0; ch < newChannels; ++ch) {
    addSingleSeries(QString("通道 %1").arg(ch + 1), QColor(namedColors.at(ch % namedColors.size())));
  }
}

void PlotWidget::setupPlot() {
  QCustomPlot *customPlot = ui->customPlot;

  customPlot->plotLayout()->setRowSpacing(0);
  QFont font = QFont("华文细黑");

  // first we create and prepare a text layout element:
  QCPTextElement *title = new QCPTextElement(customPlot);
  title->setText("Plot Title Example");
  font.setPixelSize(12);
  font.setBold(true);
  title->setFont(font);
  // then we add it to the main plot layout:
  customPlot->plotLayout()->insertRow(0);                   // insert an empty row above the axis rect
  customPlot->plotLayout()->addElement(0, 0, title);        // place the title in the empty cell we've just created

  QSharedPointer<QCPAxisTickerTime> timeTicker(new QCPAxisTickerTime);
  timeTicker->setTimeFormat("%h:%m:%s");
  customPlot->xAxis->setTicker(timeTicker);

  customPlot->axisRect()->setupFullAxesBox();

  customPlot->xAxis->setLabel("X");
  customPlot->xAxis->setRange(0, 50);
  customPlot->yAxis->setLabel("Y");
  customPlot->yAxis->setRange(0, 3.4);

  connect(customPlot->xAxis, QOverload<const QCPRange &>::of(&QCPAxis::rangeChanged), customPlot->xAxis2,
          QOverload<const QCPRange &>::of(&QCPAxis::setRange));
  connect(customPlot->yAxis, QOverload<const QCPRange &>::of(&QCPAxis::rangeChanged), customPlot->yAxis2,
          QOverload<const QCPRange &>::of(&QCPAxis::setRange));

  updatePlotTitle("波形检测");
}

int PlotWidget::channelCount() const { return m_channelCount; }

void PlotWidget::setChannelCount(int newChannelCount) {
  if (m_channelCount == newChannelCount)
    return;
  m_channelCount = newChannelCount;
  emit channelCountChanged(newChannelCount);
}
