#ifndef PLOTWIDGET_H
#define PLOTWIDGET_H

#include <QDateTime>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class PlotWidget;
}
QT_END_NAMESPACE

class QCustomPlot;

// typedef struct {
//   QDateTime key;
//   QList<qreal> data;
// } DataFrame;

class PlotWidget : public QWidget {
  Q_OBJECT

  Q_PROPERTY(int channelCount READ channelCount WRITE setChannelCount NOTIFY channelCountChanged)
public:
  PlotWidget(QWidget *parent = nullptr);
  ~PlotWidget();

  int channelCount() const;
  void setChannelCount(int newChannelCount);

protected:
  void setupPlot();

  void updatePlotTitle(const QString &newTitle);

  void updatePlotData();

  void addSingleSeries(const QString &seriesName, const QColor &seriesColor);
public slots:

  void dataComming(const qreal &key,
                   const QList<qreal> data);        // 每次1帧数据，例如，现有4通道数据，每次来的数据是 时间+ 4通道数据

  void onChannelCountChanged(int newChannels);
signals:
  void channelCountChanged(int newChannels);

private:
  Ui::PlotWidget *ui;
  QTimer *timer;

  int m_channelCount;
};
#endif        // PLOTWIDGET_H
