#include "serialoptionswidget.h"
#include "ui_serialoptionswidget.h"
#include <QDebug>
#include <QMetaEnum>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>
#define FRAME_START QByteArray("\xAA\xFF")

SerialOptionsWidget::SerialOptionsWidget(QWidget *parent) : QWidget(parent), ui(new Ui::SerialOptionsWidget) {

  mSerial = new QSerialPort(this);        // ownership
  ui->setupUi(this);
  setupUI();
  connectSerialSlots();
  updateSerialParams();
  createTest();
}

SerialOptionsWidget::~SerialOptionsWidget() { delete ui; }

void SerialOptionsWidget::setupUI() {
  // 该函数负责创建窗口界面所需的各项下拉框数据

  detectSerialPorts();

  //    串口名（另外函数来做）
  //    enum BaudRate { Baud1200, Baud2400, Baud4800, Baud9600, Baud19200, …, UnknownBaud }
  //    enum DataBits { Data5, Data6, Data7, Data8, UnknownDataBits }
  //    enum FlowControl { NoFlowControl, HardwareControl, SoftwareControl, UnknownFlowControl }
  //    enum Parity { NoParity, EvenParity, OddParity, SpaceParity, MarkParity, UnknownParity }
  //    enum StopBits { OneStop, OneAndHalfStop, TwoStop, UnknownStopBits }

  // 参数配置页面，一共有6个下拉框（QComboBox）

  // QMetaEnum::fromType //元枚举...

  auto me = QMetaEnum::fromType<QSerialPort::BaudRate>();
  for (int idx = 0; idx < me.keyCount(); ++idx) {
    //    qDebug() << me.key(idx) << me.value(idx);
    if (me.value(idx) < 0) {
      continue;
    }
    ui->comboBaud->addItem(me.key(idx), me.value(idx));
    ui->comboBaud->setCurrentIndex(ui->comboBaud->findData(QSerialPort::Baud115200));
  }

  me = QMetaEnum::fromType<QSerialPort::DataBits>();
  for (int idx = 0; idx < me.keyCount(); ++idx) {
    //    qDebug() << me.key(idx) << me.value(idx);
    if (me.value(idx) < 0) {
      continue;
    }
    ui->comboDatabit->addItem(me.key(idx), me.value(idx));
    ui->comboDatabit->setCurrentIndex(ui->comboDatabit->findData(QSerialPort::Data8));
  }

  me = QMetaEnum::fromType<QSerialPort::StopBits>();
  for (int idx = 0; idx < me.keyCount(); ++idx) {
    //    qDebug() << me.key(idx) << me.value(idx);
    if (me.value(idx) < 0) {
      continue;
    }
    ui->comboStopBit->addItem(tr(me.key(idx)), me.value(idx));
    ui->comboStopBit->setCurrentIndex(ui->comboStopBit->findData(QSerialPort::OneStop));
  }

  me = QMetaEnum::fromType<QSerialPort::Parity>();
  for (int idx = 0; idx < me.keyCount(); ++idx) {
    //    qDebug() << me.key(idx) << me.value(idx);
    if (me.value(idx) < 0) {
      continue;
    }
    ui->comboParity->addItem(tr(me.key(idx)), me.value(idx));
    ui->comboParity->setCurrentIndex(ui->comboParity->findData(QSerialPort::NoParity));
  }

  me = QMetaEnum::fromType<QSerialPort::FlowControl>();
  for (int idx = 0; idx < me.keyCount(); ++idx) {
    //    qDebug() << me.key(idx) << me.value(idx);
    if (me.value(idx) < 0) {
      continue;
    }
    ui->comboFlowControl->addItem(tr(me.key(idx)), me.value(idx));
    ui->comboFlowControl->setCurrentIndex(ui->comboFlowControl->findData(QSerialPort::NoFlowControl));
  }
}

void SerialOptionsWidget::detectSerialPorts() {

  ui->comboPort->clear();
  const auto infos = QSerialPortInfo::availablePorts();
  for (const QSerialPortInfo &info : infos) {
    auto portName = info.portName();
    ui->comboPort->addItem(portName, portName);
  }
}

void SerialOptionsWidget::updateSerialParams() {
  mSerial->setPortName(ui->comboPort->currentText());
  mSerial->setBaudRate(ui->comboBaud->currentData().toInt());
  mSerial->setDataBits(ui->comboDatabit->currentData().value<QSerialPort::DataBits>());
  mSerial->setStopBits(ui->comboStopBit->currentData().value<QSerialPort::StopBits>());
  mSerial->setParity(ui->comboParity->currentData().value<QSerialPort::Parity>());
  mSerial->setFlowControl(ui->comboFlowControl->currentData().value<QSerialPort::FlowControl>());

  qDebug() << mSerial->portName() << Qt::endl
           << mSerial->baudRate() << Qt::endl
           << mSerial->dataBits() << Qt::endl
           << mSerial->stopBits() << Qt::endl
           << mSerial->parity() << Qt::endl
           << mSerial->flowControl();
}

void SerialOptionsWidget::testSend() {
  if (timer->isActive()) {
    timer->stop();
  } else {
    timer->start();
  }
}

void SerialOptionsWidget::createTest() {
  timer = new QTimer(this);
  timer->setInterval(400);
  connect(timer, &QTimer::timeout, this, [=]() {
    mSerial->write("test");
    mSerial->write("String");
    mSerial->write(QByteArray::fromHex("30 31 32 33 34 35"));
  });
}

void SerialOptionsWidget::onSerialParamsChanged() {

  auto combo = qobject_cast<QComboBox *>(sender());
  if (combo) {
    updateSerialParams();
  }
}

void SerialOptionsWidget::updateWidgetsStatus() {
  auto allCombos = this->findChildren<QComboBox *>();

  if (ui->btnGo->text().contains("开始")) {
    ui->btnGo->setText("停止");
    for (const auto combo : allCombos) {
      combo->setEnabled(false);
    }
  } else {
    ui->btnGo->setText("开始");
    for (const auto combo : allCombos) {
      combo->setEnabled(true);
    }
  }
  testSend();
}

void SerialOptionsWidget::onBtnGoClicked() {
  //    updateWidgetsStatus();
  if (mSerial->isOpen()) {
    mSerial->close();
    //    elaTimer.invalidate();
    msgLog("关闭串口：" + mSerial->portName());
    updateWidgetsStatus();
  } else {
    msgLog(tr("[打开:] %1 ").arg(mSerial->portName()));
    if (mSerial->open(QIODevice::ReadWrite)) {
      updateWidgetsStatus();
      //      emit sigStartAcquisition();
    } else {
      msgLog(tr("[错误:]") + mSerial->errorString());
    }
  }
}

void SerialOptionsWidget::onSerialReadyRead()
{
  dataReceived.append(mSerial->readAll());

  // 帧头检查和处理
  int pos = dataReceived.indexOf(FRAME_START);

  while (pos != -1 && (dataReceived.size() - pos) >= 10) { // 确保数据包长度包括校验位
    // 检查帧长度
    if (dataReceived.at(pos + 2) != 0x06) {
      dataReceived.remove(0, pos + 1);         // 移除错误的帧头部分
      pos = dataReceived.indexOf(FRAME_START); // 重新寻找帧头
      continue;
    }

    // 计算校验和
    unsigned char checksum = 0;
    for (int i = 0; i < 9; ++i) {
      checksum += static_cast<unsigned char>(dataReceived.at(pos + i));
    }

    // 比较校验和
    if (checksum != static_cast<unsigned char>(dataReceived.at(pos + 9))) {
      dataReceived.remove(0, pos + 1);         // 校验失败，移除错误的帧头部分
      pos = dataReceived.indexOf(FRAME_START); // 重新寻找帧头
      continue;
    }

    // 提取波形数据的代码...
    int Wave1Integer = static_cast<unsigned char>(dataReceived.at(pos + 3));
    int Wave1Decimal = static_cast<unsigned char>(dataReceived.at(pos + 4));
    qreal Wave1 = Wave1Integer + Wave1Decimal / 100.0;

    int Wave2Integer = static_cast<unsigned char>(dataReceived.at(pos + 5));
    int Wave2Decimal = static_cast<unsigned char>(dataReceived.at(pos + 6));
    qreal Wave2 = Wave2Integer + Wave2Decimal / 100.0;

    int Wave3Integer = static_cast<unsigned char>(dataReceived.at(pos + 7));
    int Wave3Decimal = static_cast<unsigned char>(dataReceived.at(pos + 8));
    qreal Wave3 = Wave3Integer + Wave3Decimal / 100.0;

    qDebug() << "通道1:" << Wave1;
    qDebug() << "通道2:" << Wave2;
    qDebug() << "通道3:" << Wave3;

    QByteArray data;
    data.append(" 通道1:  " + QByteArray::number(Wave1, 'f', 2));
    data.append(" 通道2:  " + QByteArray::number(Wave2, 'f', 2));
    data.append(" 通道3:  " + QByteArray::number(Wave3, 'f', 2) + '\n');

    QList<qreal> PlotValue;
    PlotValue << Wave1 << Wave2 << Wave3;

    emit serialDataReceived(data);
    emit PlotDataReceived(PlotValue);
    // 移除处理过的数据
    dataReceived.remove(0, pos + 10);        // 包括校验位
    pos = dataReceived.indexOf(FRAME_START); // 寻找下一个帧头
  }

  // 如果没有找到完整的帧头，保留数据以便与后续接收的数据拼接
  if (pos == -1 && !dataReceived.isEmpty() && dataReceived.size() > 10) {
    dataReceived.remove(0, dataReceived.size() - 10); // 保留最后10个字节
  }

  //  qDebug() << "dataReceived" << dataReceived.size();
  //  QByteArray data = mSerial->readAll().toHex();
  //  // 处理数据
  //  emit serialDataReceived(data);
  //  qDebug() << data;
}

void SerialOptionsWidget::onSerialBytesWritten(quint64 bytes) {
  if (bytes == (quint64)QString("testString012345").toLocal8Bit().size()) {
    //    m_bytesWritten = 0;
    msgLog(tr("数据成功写入端口: [%1]").arg(mSerial->portName()));
  }
}

void SerialOptionsWidget::onSerialErrorOccurred() {

  switch (mSerial->error()) {
  case QSerialPort::NoError: msgLog(tr("[OK:]") + mSerial->portName()); break;
  default:
    if (mSerial->isOpen()) {
      mSerial->close();
      updateWidgetsStatus();
    }
    msgLog(tr("[断开:]") + mSerial->portName());
    break;
  }
}

void SerialOptionsWidget::connectSerialSlots() {
  connect(mSerial, &QSerialPort::readyRead, this, &SerialOptionsWidget::onSerialReadyRead);
  connect(mSerial, &QSerialPort::bytesWritten, this, &SerialOptionsWidget::onSerialBytesWritten);
  connect(mSerial, &QSerialPort::errorOccurred, this, &SerialOptionsWidget::onSerialErrorOccurred);
}

void SerialOptionsWidget::msgLog(const QString &msg) {
  ui->edtLogger->appendPlainText(msg);
  //  ui->edtLogger->appendPlainText("\n");
  ui->edtLogger->moveCursor(QTextCursor::End);
}
