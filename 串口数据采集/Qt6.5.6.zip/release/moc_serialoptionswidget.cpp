/****************************************************************************
** Meta object code from reading C++ file 'serialoptionswidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Qt_FPRO/serialoptionswidget.h"
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'serialoptionswidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS = QtMocHelpers::stringData(
    "SerialOptionsWidget",
    "serialDataReceived",
    "",
    "data",
    "PlotDataReceived",
    "QList<qreal>",
    "updateWidgetsStatus",
    "onSerialParamsChanged",
    "onBtnGoClicked",
    "onSerialReadyRead",
    "onSerialBytesWritten",
    "bytes",
    "onSerialErrorOccurred",
    "msgLog",
    "msg"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS_t {
    uint offsetsAndSizes[30];
    char stringdata0[20];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[17];
    char stringdata5[13];
    char stringdata6[20];
    char stringdata7[22];
    char stringdata8[15];
    char stringdata9[18];
    char stringdata10[21];
    char stringdata11[6];
    char stringdata12[22];
    char stringdata13[7];
    char stringdata14[4];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS_t qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 19),  // "SerialOptionsWidget"
        QT_MOC_LITERAL(20, 18),  // "serialDataReceived"
        QT_MOC_LITERAL(39, 0),  // ""
        QT_MOC_LITERAL(40, 4),  // "data"
        QT_MOC_LITERAL(45, 16),  // "PlotDataReceived"
        QT_MOC_LITERAL(62, 12),  // "QList<qreal>"
        QT_MOC_LITERAL(75, 19),  // "updateWidgetsStatus"
        QT_MOC_LITERAL(95, 21),  // "onSerialParamsChanged"
        QT_MOC_LITERAL(117, 14),  // "onBtnGoClicked"
        QT_MOC_LITERAL(132, 17),  // "onSerialReadyRead"
        QT_MOC_LITERAL(150, 20),  // "onSerialBytesWritten"
        QT_MOC_LITERAL(171, 5),  // "bytes"
        QT_MOC_LITERAL(177, 21),  // "onSerialErrorOccurred"
        QT_MOC_LITERAL(199, 6),  // "msgLog"
        QT_MOC_LITERAL(206, 3)   // "msg"
    },
    "SerialOptionsWidget",
    "serialDataReceived",
    "",
    "data",
    "PlotDataReceived",
    "QList<qreal>",
    "updateWidgetsStatus",
    "onSerialParamsChanged",
    "onBtnGoClicked",
    "onSerialReadyRead",
    "onSerialBytesWritten",
    "bytes",
    "onSerialErrorOccurred",
    "msgLog",
    "msg"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSerialOptionsWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   68,    2, 0x06,    1 /* Public */,
       4,    1,   71,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    0,   74,    2, 0x09,    5 /* Protected */,
       7,    0,   75,    2, 0x09,    6 /* Protected */,
       8,    0,   76,    2, 0x09,    7 /* Protected */,
       9,    0,   77,    2, 0x09,    8 /* Protected */,
      10,    1,   78,    2, 0x09,    9 /* Protected */,
      12,    0,   81,    2, 0x09,   11 /* Protected */,
      13,    1,   82,    2, 0x09,   12 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, 0x80000000 | 5,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::ULongLong,   11,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,

       0        // eod
};

Q_CONSTINIT const QMetaObject SerialOptionsWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSerialOptionsWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SerialOptionsWidget, std::true_type>,
        // method 'serialDataReceived'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'PlotDataReceived'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QList<qreal> &, std::false_type>,
        // method 'updateWidgetsStatus'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSerialParamsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onBtnGoClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSerialReadyRead'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSerialBytesWritten'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<quint64, std::false_type>,
        // method 'onSerialErrorOccurred'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'msgLog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
    >,
    nullptr
} };

void SerialOptionsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SerialOptionsWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->serialDataReceived((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->PlotDataReceived((*reinterpret_cast< std::add_pointer_t<QList<qreal>>>(_a[1]))); break;
        case 2: _t->updateWidgetsStatus(); break;
        case 3: _t->onSerialParamsChanged(); break;
        case 4: _t->onBtnGoClicked(); break;
        case 5: _t->onSerialReadyRead(); break;
        case 6: _t->onSerialBytesWritten((*reinterpret_cast< std::add_pointer_t<quint64>>(_a[1]))); break;
        case 7: _t->onSerialErrorOccurred(); break;
        case 8: _t->msgLog((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<qreal> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SerialOptionsWidget::*)(const QString & );
            if (_t _q_method = &SerialOptionsWidget::serialDataReceived; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SerialOptionsWidget::*)(const QList<qreal> & );
            if (_t _q_method = &SerialOptionsWidget::PlotDataReceived; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *SerialOptionsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialOptionsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSerialOptionsWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SerialOptionsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void SerialOptionsWidget::serialDataReceived(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SerialOptionsWidget::PlotDataReceived(const QList<qreal> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
