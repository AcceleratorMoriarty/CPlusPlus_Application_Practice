#include "gpio.h"

uint8_t key_scan(void);
